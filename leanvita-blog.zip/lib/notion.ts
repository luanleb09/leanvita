export async function getBlogPosts(pageId: string) {
  // Mock response: replace with real Notion API logic or SDK
  return [
    {
      id: 'demo-post-1',
      title: '3 Easy Tips to Start Losing Weight Today'
    },
    {
      id: 'demo-post-2',
      title: 'Why Walking Daily Improves Your Fitness'
    }
  ];
}