export const siteConfig = {
  name: 'LeanVita',
  domain: 'leanvita.online',
  description: 'A health and fitness blog powered by Notion.',
  notionPageId: '7875426197cf461698809def95960ebf', // ✅ Demo Notion DB
  author: 'LeanVita Team',
  github: 'https://github.com/yourusername/leanvita'
};